using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.IO;
using UnityEngine.EventSystems;

public class Test : MonoBehaviour
{
    public GameObject main;
    public GameObject matchPrototype;
    public GameObject newSeason;
    public GameObject teamMatch;
    public GameObject createTeam;
    public GameObject dayTable;
    public GameObject simulate;

    public Text teamNumtext;    
    public Text matchTeam1;
    public Text matchTeam2;
    public Text seasonTitle;
    public Text simulateTeam1;
    public Text simulateTeam2;
    public Text showSchedule;
    public Text monthText;
    public Text selectedText;
    public Text oppositeText;
    public InputField seasonName;
    public InputField teamNameInput;
    public Dropdown selectDrop;
    public GameObject matchBackground;
    public GameObject matchTeam;
    public GameObject august;
    public GameObject september;
    public GameObject october;
    public GameObject november;
    public GameObject december;
    public GameObject oppositeTeam;

    public Button[] dateAugust;
    public Button[] dateSeptember;
    public Button[] dateOctober;
    public Button[] dateNovember;
    public Button[] dateDecember;
    
    int teamNum;    
    List<string> teamName;
    string pathResource;

    //int[] counts;
    //bool[,] taken;
    //int[,] matchTable;

    //int teamNum;
    //List<string> teamArray;
    //List<int> matchSituation;
    //string pathSeason;

    void Start()
    {
        main.transform.localScale = new Vector3(Screen.width / 1920f, Screen.height / 1080f, 1f);
        pathResource = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "Low\\TOFHGYN\\theSCOREBOARD\\Resources\\Teams";
        //pathSeason = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "Low\\TOFHGYN\\theSCOREBOARD\\Resources\\Season";
        //StartSeasonBtnClick();
    }  
        
    //Create Team
    public void SaveTeamBtn()
    {
        if(teamNameInput.text != "")
        {
            if (!Directory.Exists(pathResource))
            {
                Directory.CreateDirectory(pathResource);
            }

            FileStream oFileStream = new FileStream(pathResource + "\\" + teamNameInput.text + ".txt", System.IO.FileMode.Create);
            oFileStream.Close();
        }              
    }   
    
    public void TournamentBtnClick()
    {
        createTeam.SetActive(false);
        newSeason.SetActive(true);

        RandomTeam(int.Parse(teamNumtext.text));
        selectDrop.ClearOptions();
        selectDrop.AddOptions(teamName);
    }
    
    // New Season
    public void UpBtnClick()
    {
        if (teamNumtext.text != "32")
        {
            teamNumtext.text = (int.Parse(teamNumtext.text) + 4).ToString();
        }

        RandomTeam(int.Parse(teamNumtext.text));
        selectDrop.ClearOptions();
        selectDrop.AddOptions(teamName);
    }

    public void DownBtnClick()
    {
        if (teamNumtext.text != "12")
        {
            teamNumtext.text = (int.Parse(teamNumtext.text) - 4).ToString();
        }

        RandomTeam(int.Parse(teamNumtext.text));
        selectDrop.ClearOptions();
        selectDrop.AddOptions(teamName);
    }

    public void StartSeasonBtnClick()
    {       
        if (seasonName.text != "")
        {
            seasonTitle.text = seasonName.text;            
            seasonName.text = "";
        }
        else
        {
            seasonTitle.text = "New Season";
        }

        teamNum = int.Parse(teamNumtext.text);

        //counts = new int[teamNum];
        //taken = new bool[teamNum, teamNum];
        //matchTable = new int[teamNum * (teamNum - 1), 2];

        //for (int i = 0; i < teamNum; i++)
        //{
        //    counts[i] = 0;
        //}

        //RandomTeam(teamNum);
        selectedText.text = selectDrop.options[selectDrop.value].text;
        ShowSchedule();

        newSeason.SetActive(false);
        teamMatch.SetActive(true);
    }

    public void SeasonBackBtnClick()
    {
        newSeason.SetActive(false);
        createTeam.SetActive(true);
    }

    //Team Match
    public void TeamMatchBackBtnClick()
    {
        teamMatch.SetActive(false);
        newSeason.SetActive(true);
        showSchedule.text = "";
    }   

    public void DayBtnClick()
    {
        oppositeTeam.SetActive(true);
        string temp = "";
        oppositeText.text = "";

        if (monthText.text == "August")
        {
            temp = dateAugust[int.Parse(EventSystem.current.currentSelectedGameObject.name)].GetComponentInChildren<Text>().text;                        
        }
        else if (monthText.text == "September")
        {
            temp = dateSeptember[int.Parse(EventSystem.current.currentSelectedGameObject.name)].GetComponentInChildren<Text>().text;
        }
        else if (monthText.text == "October")
        {
            temp = dateOctober[int.Parse(EventSystem.current.currentSelectedGameObject.name)].GetComponentInChildren<Text>().text;
        }
        else if (monthText.text == "November")
        {
            temp = dateNovember[int.Parse(EventSystem.current.currentSelectedGameObject.name)].GetComponentInChildren<Text>().text;
        }
        else if (monthText.text == "December")
        {
            temp = dateDecember[int.Parse(EventSystem.current.currentSelectedGameObject.name)].GetComponentInChildren<Text>().text;
        }

        if (temp[temp.Length - 1] == 'H' || temp[temp.Length - 1] == 'A')
        {
            for (int i = 0; i < temp.Length - 1; i++)
            {
                oppositeText.text += temp[i];
            }
        }
        else
        {
            oppositeTeam.SetActive(false);
            oppositeText.text = "None";
        }
    }

    public void StartSimulateBtnClick()
    {
        if(oppositeText.text != "None")
        {
            simulateTeam1.text = selectedText.text;
            simulateTeam2.text = oppositeText.text;

            simulate.SetActive(true);
            teamMatch.SetActive(false);
        }               
    }

    public void PrevBtnClick()
    {
        if(monthText.text == "September")
        {
            monthText.text = "August";
            september.SetActive(false);
            august.SetActive(true);
            august.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            september.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            october.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            november.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            december.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);

        }
        else if(monthText.text == "October")
        {
            monthText.text = "September";
            october.SetActive(false);
            september.SetActive(true);
            august.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            september.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            october.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            november.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            december.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
        }
        else if(monthText.text == "November")
        {
            monthText.text = "October";
            november.SetActive(false);
            october.SetActive(true);
            august.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            september.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            october.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            november.transform.position -= new Vector3(0, 875f * (Screen.height / 1080f), 0);
            december.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
        }
        else if (monthText.text == "December")
        {
            monthText.text = "November";
            december.SetActive(false);
            november.SetActive(true);
            august.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            september.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            october.transform.position -= new Vector3(0, 700f * (Screen.height / 1080f), 0);
            november.transform.position -= new Vector3(0, 875f * (Screen.height / 1080f), 0);
            december.transform.position -= new Vector3(0, 1050f * (Screen.height / 1080f), 0);
        }
    }

    public void NextBtnClick()
    {
        if (monthText.text == "August")
        {
            monthText.text = "September";
            september.SetActive(true);
            august.SetActive(false);
            august.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            september.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            october.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            november.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            december.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
        }
        else if (monthText.text == "September")
        {
            monthText.text = "October";
            october.SetActive(true);
            september.SetActive(false);
            august.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            september.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            october.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            november.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            december.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
        }
        else if (monthText.text == "October")
        {
            monthText.text = "November";
            november.SetActive(true);
            october.SetActive(false);
            august.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            september.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            october.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            november.transform.position += new Vector3(0, 875f * (Screen.height / 1080f), 0);
            december.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
        }
        else if (monthText.text == "November")
        {
            monthText.text = "December";
            december.SetActive(true);
            november.SetActive(false);
            august.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            september.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            october.transform.position += new Vector3(0, 700f * (Screen.height / 1080f), 0);
            november.transform.position += new Vector3(0, 875f * (Screen.height / 1080f), 0);
            december.transform.position += new Vector3(0, 1050f * (Screen.height / 1080f), 0);
        }
    }

    public void SimulateBackBtnClick()
    {
        simulate.SetActive(false);
        teamMatch.SetActive(true);
        oppositeTeam.SetActive(false);
    }

    /////////////////////////////////////////////////////////////////////////////////
    static class Constants
    {
        //    Maximum Team Count
        public const int MaxN = 32;

        //    Maximum Game Count
        public const int MaxM = MaxN * MaxN * 3;

        //    Limit Count of Match in 1 day
        public const int MaxCountForOneDay = 15;
    }

    public class Pair<T, U>
    {
        public Pair() { }

        public Pair(T first, U second)
        {
            this.First = first;
            this.Second = second;
        }

        public T First { get; set; }
        public U Second { get; set; }
    };    

    public void ShowSchedule()
    {
        int N, M;
        Pair<int, int>[] Games = new Pair<int, int>[Constants.MaxM];
        int[] GameInfo = new int[Constants.MaxM];
        int[] PlayInfo = new int[Constants.MaxN];
        N = teamNum;
        M = N * (N - 1);

        int[] GameId = new int[M];

        for (int i = 0, k = 0; i < N; i++)
        {
            PlayInfo[i] = 0;

            for (int j = 0; j < N; j++)
            {
                if (i == j) continue;
                Games[k] = new Pair<int, int>(i, j);
                GameId[k] = k;
                GameInfo[k] = 0;
                k++;
            }
        }

        // Sheduling
        System.Random random = new System.Random();
        DateTime today = DateTime.Today;
        DateTime current = today;
        int ret = 0;
        int match_cnt = 0;

        while (match_cnt < M)
        {
            ret++;
            current = current.AddDays(1);
            int today_cnt = random.Next() % Constants.MaxCountForOneDay;

            if (today_cnt == 0)
            {
                continue;
            }

            GameId = GameId.OrderBy(x => random.Next()).ToArray();

            //print(current);

            for (int i = 0; i < M && match_cnt < M && today_cnt > 0; i++)
            {
                int id = GameId[i];

                if (GameInfo[id] > 0)
                {
                    continue;
                }

                int home = Games[id].First;
                int away = Games[id].Second;

                if (PlayInfo[home] == ret || PlayInfo[away] == ret)
                {
                    continue;
                }

                PlayInfo[home] = PlayInfo[away] = GameInfo[id] = ret;

                //print("Team" + (home + 1).ToString() + " VS Team" + (away + 1).ToString());

                today_cnt--;
                match_cnt++;
            }
        }

        int ID = 1;
        int cnt = (N - 1) * 2;
        SortedList<int, string> sch = new SortedList<int, string>();
        ID--;

        for (int i = 0; i < M; i++)
        {
            int home = Games[i].First;
            int away = Games[i].Second;
            int day = GameInfo[i];

            if(home == away)
            {
                continue;
            }

            if (home == ID)
            {
                sch.Add(day, "Team" + (away + 1).ToString() + "H");
            }

            if (away == ID)
            {
                sch.Add(day, "Team" + (home + 1).ToString() + "A");
            }
        }

        foreach (var item in sch)
        {
            int day = item.Key;
            DateTime d = today.AddDays(day);

            if(d.Month == 8)
            {
                dateAugust[d.Day - 1].GetComponentInChildren<Text>().text = item.Value.ToString();
            }
            else if(d.Month == 9)
            {
                dateSeptember[d.Day - 1].GetComponentInChildren<Text>().text = item.Value.ToString();
            }
            else if (d.Month == 10)
            {
                dateOctober[d.Day - 1].GetComponentInChildren<Text>().text = item.Value.ToString();
            }
            else if (d.Month == 11)
            {
                dateNovember[d.Day - 1].GetComponentInChildren<Text>().text = item.Value.ToString();
            }
            else if (d.Month == 12)
            {
                dateDecember[d.Day - 1].GetComponentInChildren<Text>().text = item.Value.ToString();
            }

            //showSchedule.text += d.Month + "." + d.Day.ToString() + " : " + item.Value.ToString() + "     ";
            //print(d.Day);
            //print(item.Value);
        }
    }

    public void RandomTeam(int num)
    {
        teamName = new List<string>();
        //teamArray = new List<string>();

        //for (int i = 0; i < 4; i++)
        //{
        //    teamName.Add("Manual" + (i + 1).ToString());
        //}

        //Teamname Random Producing        
        for (int i = 0; i < int.Parse(teamNumtext.text); i++)
        {
            teamName.Add("Team" + (i + 1).ToString());
        }
    }

    //public void MatchTable()
    //{
    //    int first, second, k, curCnt = 0;

    //    for (first = 0; first < teamNum; first++)
    //    {
    //        for (second = 0; second < teamNum; second++)
    //        {
    //            taken[first, second] = false;
    //        }
    //    }

    //    while (true)
    //    {
    //        if (curCnt >= teamNum * (teamNum - 1))
    //            break;  //all pairs are taken

    //        while (true)
    //        {
    //            //bool flag = false;              
    //            first = UnityEngine.Random.Range(1, 100) % teamNum;                

    //            k = 0;
    //            int[] temp;
    //            temp = new int[teamNum];

    //            for (second = 0; second < teamNum; second++)
    //            {
    //                if (second != first && !taken[first, second])
    //                    temp[k++] = second;
    //            }

    //            if (k > 0)
    //            {
    //                second = temp[UnityEngine.Random.Range(1, 100) % k];
    //                taken[first, second] = true;
    //                matchTable[curCnt, 0] = first;
    //                matchTable[curCnt, 1] = second;
    //                break;
    //            }
    //        }

    //        curCnt++;
    //    }
    //}

    //public void DayTableBackBtnClick()
    //{
    //    dayTable.SetActive(false);
    //    GameObject[] destroyTeam1 = GameObject.FindGameObjectsWithTag("NormalPair");
    //    GameObject[] destroyTeam2 = GameObject.FindGameObjectsWithTag("SimulatePair");

    //    if (destroyTeam1.Length != 0)
    //    {
    //        for (int i = 0; i < destroyTeam1.Length; i++)
    //        {
    //            Destroy(destroyTeam1[i]);
    //        }
    //    }

    //    if (destroyTeam2.Length != 0)
    //    {
    //        for (int i = 0; i < destroyTeam2.Length; i++)
    //        {
    //            Destroy(destroyTeam2[i]);
    //        }
    //    }
    //}

    //public void DayBtnClick()
    //{
    //    int btnNum = int.Parse(EventSystem.current.currentSelectedGameObject.name);
    //    string[,] dayTeam;
    //    dayTeam = new string[12, 2];

    //    for (int i = 0; i < 12; i++)
    //    {
    //        dayTeam[i, 0] = teamName[matchTable[i + btnNum * 12, 0]];
    //        dayTeam[i, 1] = teamName[matchTable[i + btnNum * 12, 1]];
    //        matchTeam1.text = dayTeam[i, 0];
    //        matchTeam2.text = dayTeam[i, 1];

    //        GameObject clone = Instantiate(matchTeam, new Vector3(Screen.width / 2.0f + (i % 3 - 1) * 500f, 900f - 250f * (i / 3), 0), Quaternion.identity, teamMatch.transform);
    //        clone.tag = "NormalPair";
    //        clone.name = matchTeam1.text + "," + matchTeam2.text;

    //        if (matchTeam1.text[0] != '?' || matchTeam2.text[0] != '?')
    //        {
    //            clone.tag = "SimulatePair";
    //        }            
    //    }

    //    dayTable.SetActive(true);
    //}
}