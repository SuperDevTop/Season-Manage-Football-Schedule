using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TestUI : MonoBehaviour
{
    public GameObject newTournament;
    public GameObject teamMatch;
    public Text teamNumtext;
    public InputField tournamentName;   

    // New Tournament
    public void UpBtnClick()
    {
        if(teamNumtext.text != "32")
        {
            teamNumtext.text = (int.Parse(teamNumtext.text) + 1).ToString();
        }
    }

    public void DownBtnClick()
    {
        if (teamNumtext.text != "2")
        {
            teamNumtext.text = (int.Parse(teamNumtext.text) - 1).ToString();
        }
    }

    public void StartTournamentBtnClick()
    {
        if(tournamentName.text != "")
        {
            newTournament.SetActive(false);
            teamMatch.SetActive(true);
            //isStartedTour = true;            
        }      
    }

    //Team Match
    public void TeamMatchBackBtnClick()
    {
        teamMatch.SetActive(false);
        newTournament.SetActive(true);
    }
}
