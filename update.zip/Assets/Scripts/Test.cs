
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.IO;
using UnityEngine.EventSystems;

public class Test : MonoBehaviour
{
    public GameObject main;
    public GameObject matchPrototype;
    public GameObject newSeason;
    public GameObject teamMatch;
    public GameObject createTeam;
    public GameObject dayTable;
    public GameObject simulate;

    public Text teamNumtext;    
    public Text matchTeam1;
    public Text matchTeam2;
    public Text seasonTitle;
    public Text simulateTeam1;
    public Text simulateTeam2;
    public Text showSchedule;
    public Text monthText;
    public Text selectedText;
    public Text oppositeText;
    public InputField seasonName;
    public InputField teamNameInput;
    public Dropdown selectDrop;
    public GameObject matchBackground;
    public GameObject matchTeam;
    public GameObject august;
    public GameObject september;
    public GameObject october;
    public GameObject november;
    public GameObject december;
    public GameObject oppositeTeam;

    public Button[] dateAugust;
    public Button[] dateSeptember;
    public Button[] dateOctober;
    public Button[] dateNovember;
    public Button[] dateDecember;
    
    int teamNum;    
    List<string> teamName;
    string pathResource;

    void Start()
    {
        main.transform.localScale = new Vector3(Screen.width / 1920f, Screen.height / 1080f, 1f);
        pathResource = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "Low\\TOFHGYN\\theSCOREBOARD\\Resources\\Teams";
    }  
        
    //Create Team
    public void SaveTeamBtn()
    {
        if(!string.Equals(teamNameInput.text, ""))
        {
            if (!Directory.Exists(pathResource))
            {
                Directory.CreateDirectory(pathResource);
            }

            FileStream oFileStream = new FileStream(pathResource + "\\" + teamNameInput.text + ".txt", System.IO.FileMode.Create);
            oFileStream.Close();
        }              
    }   
    
    public void TournamentBtnClick()
    {
        createTeam.SetActive(false);
        newSeason.SetActive(true);
        RandomTeam(int.Parse(teamNumtext.text));
        selectDrop.ClearOptions();
        selectDrop.AddOptions(teamName);
    }
    
    // New Season
    public void UpBtnClick()
    {
        if (!string.Equals(teamNumtext.text, "32"))
        {
            teamNumtext.text = (int.Parse(teamNumtext.text) + 4).ToString();
        }

        RandomTeam(int.Parse(teamNumtext.text));
        selectDrop.ClearOptions();
        selectDrop.AddOptions(teamName);
    }

    public void DownBtnClick()
    {
        if (!string.Equals(teamNumtext.text, "12"))
        {
            teamNumtext.text = (int.Parse(teamNumtext.text) - 4).ToString();
        }

        RandomTeam(int.Parse(teamNumtext.text));
        selectDrop.ClearOptions();
        selectDrop.AddOptions(teamName);
    }

    public void StartSeasonBtnClick()
    {       
        if (!string.Equals(seasonName.text, ""))
        {
            seasonTitle.text = seasonName.text;         
            seasonName.text = "";
        }
        else
        {
            seasonTitle.text = "New Season";
        }

        teamNum = int.Parse(teamNumtext.text);
        selectedText.text = selectDrop.options[selectDrop.value].text;
        ShowSchedule();

        newSeason.SetActive(false);
        teamMatch.SetActive(true);
    }

    public void SeasonBackBtnClick()
    {
        newSeason.SetActive(false);
        createTeam.SetActive(true);
    }

    //Team Match
    public void TeamMatchBackBtnClick()
    {
        teamMatch.SetActive(false);
        newSeason.SetActive(true);
        showSchedule.text = "";
    }   

    public void DayBtnClick()
    {
        oppositeTeam.SetActive(true);
        int selectedDay = int.Parse(EventSystem.current.currentSelectedGameObject.name);
        string temp = "";
        oppositeText.text = "";

        if (string.Equals(monthText.text, Months.August.ToString()))
        {
            temp = dateAugust[selectedDay].GetComponentInChildren<Text>().text;                        
        }
        else if (string.Equals(monthText.text, Months.September.ToString()))
        {
            temp = dateSeptember[selectedDay].GetComponentInChildren<Text>().text;
        }
        else if (string.Equals(monthText.text, Months.October.ToString()))
        {
            temp = dateOctober[selectedDay].GetComponentInChildren<Text>().text;
        }
        else if (string.Equals(monthText.text, Months.November.ToString()))
        {
            temp = dateNovember[selectedDay].GetComponentInChildren<Text>().text;
        }
        else if (string.Equals(monthText.text, Months.December.ToString()))
        {
            temp = dateDecember[selectedDay].GetComponentInChildren<Text>().text;
        }

        if (temp[temp.Length - 1] == 'H' || temp[temp.Length - 1] == 'A')
        {
            for (int i = 0; i < temp.Length - 1; i++)
            {
                oppositeText.text += temp[i];
            }
        }
        else
        {
            oppositeTeam.SetActive(false);
            oppositeText.text = "None";
        }
    }

    public void StartSimulateBtnClick()
    {
        if(!string.Equals(oppositeText.text, "None"))
        {
            simulateTeam1.text = selectedText.text;
            simulateTeam2.text = oppositeText.text;
            simulate.SetActive(true);
            teamMatch.SetActive(false);
        }               
    }

    public void PrevBtnClick()
    {
        Vector3 vector1 = new Vector3(0, 700f * (Screen.height / 1080f), 0);
        Vector3 vector2 = new Vector3(0, 875f * (Screen.height / 1080f), 0);
        Vector3 vector3 = new Vector3(0, 1050f * (Screen.height / 1080f), 0);

        if (string.Equals(monthText.text, Months.September.ToString()))
        {
            monthText.text = Months.August.ToString();
            september.SetActive(false);
            august.SetActive(true);
            SetTransformPosition(august.transform, -vector1);
            SetTransformPosition(september.transform, -vector1);
            SetTransformPosition(october.transform, -vector1);
            SetTransformPosition(november.transform, -vector1);
            SetTransformPosition(december.transform, -vector1);
        }
        else if(string.Equals(monthText.text, Months.October.ToString()))
        {
            monthText.text = Months.September.ToString();
            october.SetActive(false);
            september.SetActive(true);
            SetTransformPosition(august.transform, -vector1);
            SetTransformPosition(september.transform, -vector1);
            SetTransformPosition(october.transform, -vector1);
            SetTransformPosition(november.transform, -vector1);
            SetTransformPosition(december.transform, -vector1);
        }
        else if(string.Equals(monthText.text, Months.November.ToString()))
        {
            monthText.text = Months.October.ToString();
            november.SetActive(false);
            october.SetActive(true);
            SetTransformPosition(august.transform, -vector1);
            SetTransformPosition(september.transform, -vector1);
            SetTransformPosition(october.transform, -vector1);
            SetTransformPosition(november.transform, -vector2);
            SetTransformPosition(december.transform, -vector1);
        }
        else if (string.Equals(monthText.text, Months.December.ToString()))
        {
            monthText.text = Months.November.ToString();
            december.SetActive(false);
            november.SetActive(true);
            SetTransformPosition(august.transform, -vector1);
            SetTransformPosition(september.transform, -vector1);
            SetTransformPosition(october.transform, -vector1);
            SetTransformPosition(november.transform, -vector2);
            SetTransformPosition(december.transform, -vector3);
        }
    }

    public void NextBtnClick()
    {
        Vector3 vector1 = new Vector3(0, 700f * (Screen.height / 1080f), 0);
        Vector3 vector2 = new Vector3(0, 875f * (Screen.height / 1080f), 0);
        Vector3 vector3 = new Vector3(0, 1050f * (Screen.height / 1080f), 0);

        if (string.Equals(Months.August.ToString(), monthText.text))
        {
            monthText.text = Months.September.ToString();
            september.SetActive(true);
            august.SetActive(false);
            SetTransformPosition(august.transform, vector1);
            SetTransformPosition(september.transform, vector1);
            SetTransformPosition(october.transform, vector1);
            SetTransformPosition(november.transform, vector1);
            SetTransformPosition(december.transform, vector1);
        }
        else if (monthText.text == Months.September.ToString())
        {
            monthText.text = Months.October.ToString();
            october.SetActive(true);
            september.SetActive(false);
            SetTransformPosition(august.transform, vector1);
            SetTransformPosition(september.transform, vector1);
            SetTransformPosition(october.transform, vector1);
            SetTransformPosition(november.transform, vector1);
            SetTransformPosition(december.transform, vector1);
        }
        else if (monthText.text == Months.October.ToString())
        {
            monthText.text = Months.November.ToString();
            november.SetActive(true);
            october.SetActive(false);
            SetTransformPosition(august.transform, vector1);
            SetTransformPosition(september.transform, vector1);
            SetTransformPosition(october.transform, vector1);
            SetTransformPosition(november.transform, vector2);
            SetTransformPosition(december.transform, vector1);
        }
        else if (monthText.text == Months.November.ToString())
        {
            monthText.text = Months.December.ToString();
            december.SetActive(true);
            november.SetActive(false);
            SetTransformPosition(august.transform, vector1);
            SetTransformPosition(september.transform, vector1);
            SetTransformPosition(october.transform, vector1);
            SetTransformPosition(november.transform, vector2);
            SetTransformPosition(december.transform, vector3);
        }
    }

    void SetTransformPosition(Transform transform, Vector3 pos)
    {
        transform.position += pos;
    }

    public void SimulateBackBtnClick()
    {
        simulate.SetActive(false);
        teamMatch.SetActive(true);
        oppositeTeam.SetActive(false);
    }

    /////////////////////////////////////////////////////////////////////////////////
    public enum Months
    {
        January,
        Feburuary,
        March,
        April,
        May,
        June,
        July,
        August,
        September,
        October,
        November,
        December
    }    
    
    static class Constants
    {
        //    Maximum Team Count
        public const int MaxN = 32;

        //    Maximum Game Count
        public const int MaxM = MaxN * MaxN * 3;

        //    Limit Count of Match in 1 day
        public const int MaxCountForOneDay = 15;
    }

    public class Pair<T, U>
    {
        public Pair() { }

        public Pair(T first, U second)
        {
            this.First = first;
            this.Second = second;
        }

        public T First { get; set; }
        public U Second { get; set; }
    };    

    public void ShowSchedule()
    {
        int N, M;
        Pair<int, int>[] Games = new Pair<int, int>[Constants.MaxM];
        int[] GameInfo = new int[Constants.MaxM];
        int[] PlayInfo = new int[Constants.MaxN];
        N = teamNum;
        M = N * (N - 1);

        int[] GameId = new int[M];

        for (int i = 0, k = 0; i < N; i++)
        {
            PlayInfo[i] = 0;

            for (int j = 0; j < N; j++)
            {
                if (i == j) continue;
                Games[k] = new Pair<int, int>(i, j);
                GameId[k] = k;
                GameInfo[k] = 0;
                k++;
            }
        }

        // Sheduling
        System.Random random = new System.Random();
        DateTime today = DateTime.Today;
        DateTime current = today;
        int ret = 0;
        int match_cnt = 0;

        while (match_cnt < M)
        {
            ret++;
            current = current.AddDays(1);
            int today_cnt = random.Next() % Constants.MaxCountForOneDay;

            if (today_cnt == 0)
            {
                continue;
            }

            GameId = GameId.OrderBy(x => random.Next()).ToArray();

            for (int i = 0; i < M && match_cnt < M && today_cnt > 0; i++)
            {
                int id = GameId[i];

                if (GameInfo[id] > 0)
                {
                    continue;
                }

                int home = Games[id].First;
                int away = Games[id].Second;

                if (PlayInfo[home] == ret || PlayInfo[away] == ret)
                {
                    continue;
                }

                PlayInfo[home] = PlayInfo[away] = GameInfo[id] = ret;
                today_cnt--;
                match_cnt++;
            }
        }

        int ID = 1;
        int cnt = (N - 1) * 2;
        SortedList<int, string> sch = new SortedList<int, string>();
        ID--;

        for (int i = 0; i < M; i++)
        {
            int home = Games[i].First;
            int away = Games[i].Second;
            int day = GameInfo[i];

            if(home == away)
            {
                continue;
            }

            if (home == ID)
            {
                sch.Add(day, "Team" + (away + 1).ToString() + "H");
            }

            if (away == ID)
            {
                sch.Add(day, "Team" + (home + 1).ToString() + "A");
            }
        }

        foreach (var item in sch)
        {
            int day = item.Key;
            DateTime d = today.AddDays(day);

            if(d.Month == 8)
            {
                dateAugust[d.Day - 1].GetComponentInChildren<Text>().text = item.Value.ToString();
            }
            else if(d.Month == 9)
            {
                dateSeptember[d.Day - 1].GetComponentInChildren<Text>().text = item.Value.ToString();
            }
            else if (d.Month == 10)
            {
                dateOctober[d.Day - 1].GetComponentInChildren<Text>().text = item.Value.ToString();
            }
            else if (d.Month == 11)
            {
                dateNovember[d.Day - 1].GetComponentInChildren<Text>().text = item.Value.ToString();
            }
            else if (d.Month == 12)
            {
                dateDecember[d.Day - 1].GetComponentInChildren<Text>().text = item.Value.ToString();
            }
        }
    }

    public void RandomTeam(int num)
    {
        teamName = new List<string>();

        //Teamname Random Producing        
        for (int i = 0; i < int.Parse(teamNumtext.text); i++)
        {
            teamName.Add("Team" + (i + 1).ToString());
        }
    }    
}